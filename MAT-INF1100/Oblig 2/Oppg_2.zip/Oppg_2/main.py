from Euler import Euler

import matplotlib.pyplot as plt
import numpy as np
from numpy import cos

eq_1 = Euler(0, 1, lambda x,y: y * (0.5 - y))

forward_euler = eq_1.forward_euler([0,3], 6)
plt.plot(forward_euler[0], forward_euler[1], label="forward euler")

midpoint_euler = eq_1.midpoint_euler([0,3], 6)
plt.plot(midpoint_euler[0], midpoint_euler[1], label="midpoint euler")

analytic = lambda x: -1/(np.exp(-x/2) - 2)

x = np.linspace(0, 3, 101)
y = np.vectorize(analytic)

plt.plot(x, y(x), label="analytic")

plt.legend()
plt.show()